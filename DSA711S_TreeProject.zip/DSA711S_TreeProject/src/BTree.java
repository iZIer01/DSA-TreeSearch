import java.util.Arrays;

// BTree class that implements all operations for the B-Tree
public class BTree {
    private static final int T = 3;  // Minimum degree t=3
    private Node root;

    // Node class represents a node in the B-Tree
    private class Node {
        int[] keys = new int[2 * T - 1];  // Maximum number of keys
        Node[] children = new Node[2 * T];  // Maximum number of children
        int numKeys = 0;
        boolean isLeaf = true;

        // Constructor to initialize a node
        Node() {
            Arrays.fill(children, null);
        }
    }

    // Constructor for BTree with minimum degree t=3
    public BTree(int t) {
        root = new Node();
    }

    // Insert a key into the B-Tree
    public void insert(int key) {
        Node rootNode = root;

        // If the root node is full, split it
        if (rootNode.numKeys == (2 * T - 1)) {
            Node newRoot = new Node();
            newRoot.children[0] = rootNode;
            root = newRoot;
            splitChild(newRoot, 0);
        }

        insertNonFull(root, key);  // Insert into non-full node
    }

    // Split a child node when it's full
    private void splitChild(Node parent, int index) {
        Node fullChild = parent.children[index];
        Node newChild = new Node();
        parent.children[index + 1] = newChild;
        parent.keys[index] = fullChild.keys[T - 1];
        parent.numKeys++;

        // Move the last (T - 1) keys from fullChild to newChild
        for (int i = 0; i < T - 1; i++) {
            newChild.keys[i] = fullChild.keys[i + T];
        }

        // If the fullChild is not a leaf, move the child pointers
        if (!fullChild.isLeaf) {
            for (int i = 0; i < T; i++) {
                newChild.children[i] = fullChild.children[i + T];
            }
        }

        fullChild.numKeys = T - 1;
    }

    // Insert a key into a node that is not full
    private void insertNonFull(Node node, int key) {
        int i = node.numKeys - 1;

        if (node.isLeaf) {
            // Find the position to insert the key in the leaf node
            while (i >= 0 && key < node.keys[i]) {
                node.keys[i + 1] = node.keys[i];
                i--;
            }
            node.keys[i + 1] = key;
            node.numKeys++;
        } else {
            // Find the child node where the key should be inserted
            while (i >= 0 && key < node.keys[i]) {
                i--;
            }
            i++;

            // If the child is full, split it
            if (node.children[i].numKeys == (2 * T - 1)) {
                splitChild(node, i);

                if (key > node.keys[i]) {
                    i++;
                }
            }

            // Insert the key into the appropriate child
            insertNonFull(node.children[i], key);
        }
    }

    // Search for a key in the B-Tree
    public void search(int key) {
        Node node = search(root, key);
        if (node != null) {
            System.out.println("Key " + key + " found in the B-Tree.");
        } else {
            System.out.println("Key " + key + " not found in the B-Tree.");
        }
    }

    // Recursive function to search for a key in the tree
    private Node search(Node node, int key) {
        int i = 0;
        while (i < node.numKeys && key > node.keys[i]) {
            i++;
        }

        // Check if the key is found in the current node
        if (i < node.numKeys && key == node.keys[i]) {
            return node;
        }

        // If it's a leaf node, the key is not found
        if (node.isLeaf) {
            return null;
        }

        // Recurse into the appropriate child
        return search(node.children[i], key);
    }

    // Postorder traversal of the B-Tree
    public void postOrder() {
        postOrder(root);
    }

    // Recursive function for postorder traversal
    private void postOrder(Node node) {
        if (node != null) {
            for (int i = 0; i < node.numKeys + 1; i++) {
                postOrder(node.children[i]);
            }
            for (int i = 0; i < node.numKeys; i++) {
                System.out.print(node.keys[i] + " ");
            }
        }
    }
}
