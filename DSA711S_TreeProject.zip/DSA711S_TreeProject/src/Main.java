import java.util.*;

// Main class where the program runs
public class Main {
    public static void main(String[] args) {
        // Create a scanner object to take user input
        Scanner scanner = new Scanner(System.in);

        // Initialize the different tree structures
        BinarySearchTree bst = new BinarySearchTree();
        AVLTree avl = new AVLTree();
        RedBlackTree rbt = new RedBlackTree();
        BTree btree = new BTree(3); // B-Tree with minimum degree t=3

        // Inserting some elements into all trees
        int[] elements = {7, 5, 9, 4, 6, 8, 13, 2};
        for (int elem : elements) {
            bst.insert(elem);  // Insert into Binary Search Tree
            avl.root = avl.insert(avl.root, elem);  // Insert into AVL Tree
            rbt.insert(elem);  // Insert into Red-Black Tree
            btree.insert(elem);  // Insert into B-Tree
        }

        // Start an infinite loop to show the menu and take user choices
        while (true) {
            System.out.println("\n===================TREE IMPLEMENTATION MENU===================");
            System.out.println("1. Binary Search Tree (Insert Node 3)");  // Option 1 to insert node 3 in BST
            System.out.println("2. Binary Search Tree (Postorder Traversal)");  // Option 2 to display BST postorder traversal
            System.out.println("3. AVL Tree (Inorder Traversal)");  // Option 3 to display AVL tree inorder traversal
            System.out.println("4. Red Black Tree (Postorder Traversal)");  // Option 4 to display Red-Black Tree postorder traversal
            System.out.println("5. B-Tree (Search for key 8)");  // Option 5 to search for the key 8 in B-Tree
            System.out.println("6. Exit");  // Option 6 to exit the program
            System.out.print("Choose an option: ");  // Prompt user for input
            int choice = scanner.nextInt();  // Take input from the user

            // Switch case to handle different options chosen by the user
            switch (choice) {
                case 1:
                    bst.insert(3);  // Insert node with value 3 into BST
                    System.out.println("Node 3 inserted into BST.");  // Output confirmation message
                    break;
                case 2:
                    System.out.print("BST Postorder: ");  // Output label for BST postorder
                    bst.postOrder();  // Call postOrder function to print the BST in postorder
                    break;
                case 3:
                    System.out.print("AVL Inorder: ");  // Output label for AVL tree inorder
                    avl.inOrder(avl.root);  // Call inorder function to print the AVL tree in inorder
                    break;
                case 4:
                    System.out.print("Red Black Tree Postorder: ");  // Output label for Red-Black Tree postorder
                    rbt.printPostOrder();  // Call printPostOrder function to print Red-Black Tree in postorder
                    break;
                case 5:
                    System.out.println("Searching for 8 in B-Tree:");  // Output label for B-Tree search
                    btree.search(8);  // Call search function to search for key 8 in the B-Tree
                    break;
                case 6:
                    System.out.println("Exiting...");  // Output message when exiting
                    return;  // Exit the program
                default:
                    System.out.println("Invalid choice. Try again.");  // Error message for invalid input
            }
        }
    }
}


