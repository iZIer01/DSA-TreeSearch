// Define the BinarySearchTree class
class BinarySearchTree {

    // Inner class to define the structure of a tree node
    class Node {
        int key;         // The value (or key) of the node
        Node left, right; // Pointers to the left and right child nodes

        // Constructor to create a new node with the given key
        public Node(int item) {
            key = item;
            left = right = null; // Initially, no children
        }
    }

    Node root; // Root node of the BST

    // Constructor to initialize an empty BST
    BinarySearchTree() {
        root = null;
    }

    // Public method to insert a key into the BST
    void insert(int key) {
        root = insertRec(root, key); // Call the recursive helper
    }

    // Recursive helper method to insert a new key in the subtree rooted at 'root'
    Node insertRec(Node root, int key) {
        // If the tree is empty, return a new node as root
        if (root == null) {
            root = new Node(key);
            return root;
        }

        // If key is smaller, insert in the left subtree
        if (key < root.key)
            root.left = insertRec(root.left, key);
            // If key is greater, insert in the right subtree
        else if (key > root.key)
            root.right = insertRec(root.right, key);

        // Return the unchanged root node
        return root;
    }

    // Public method to start postorder traversal from the root
    void postOrder() {
        postOrderRec(root); // Call the recursive helper
        System.out.println(); // Print a newline after traversal
    }

    // Recursive method for postorder traversal: left -> right -> root
    void postOrderRec(Node root) {
        if (root != null) {
            postOrderRec(root.left);   // Visit left subtree
            postOrderRec(root.right);  // Visit right subtree
            System.out.print(root.key + " "); // Print current node
        }
    }
}
