// Define the RedBlackTree class
class RedBlackTree {

    // Define node colors
    private static final boolean RED = true;
    private static final boolean BLACK = false;

    // Node class for Red-Black Tree
    class Node {
        int key;          // Value of the node
        boolean color;    // Node color (RED or BLACK)
        Node left, right, parent;

        // Constructor for a new node
        Node(int key) {
            this.key = key;
            color = RED; // New nodes are initially RED
            left = right = parent = null;
        }
    }

    private Node root;

    // Public method to insert a key
    public void insert(int key) {
        Node node = new Node(key); // Create new node
        root = bstInsert(root, node); // Standard BST insert
        fixViolation(node); // Fix any Red-Black Tree violations
    }

    // Standard BST insert logic with parent tracking
    private Node bstInsert(Node root, Node node) {
        if (root == null)
            return node;

        if (node.key < root.key) {
            root.left = bstInsert(root.left, node);
            root.left.parent = root;
        } else if (node.key > root.key) {
            root.right = bstInsert(root.right, node);
            root.right.parent = root;
        }

        return root;
    }

    // Fix RBT properties after insertion
    private void fixViolation(Node node) {
        Node parent, grandparent;

        while (node != root && node.parent.color == RED) {
            parent = node.parent;
            grandparent = parent.parent;

            // Parent is left child of grandparent
            if (parent == grandparent.left) {
                Node uncle = grandparent.right;

                // Case 1: Uncle is RED → recoloring
                if (uncle != null && uncle.color == RED) {
                    grandparent.color = RED;
                    parent.color = BLACK;
                    uncle.color = BLACK;
                    node = grandparent;
                } else {
                    // Case 2: Node is right child → left rotate
                    if (node == parent.right) {
                        node = parent;
                        leftRotate(node);
                    }
                    // Case 3: Node is left child → right rotate
                    parent.color = BLACK;
                    grandparent.color = RED;
                    rightRotate(grandparent);
                }
            } else {
                // Mirror case: Parent is right child of grandparent
                Node uncle = grandparent.left;

                // Case 1: Uncle is RED
                if (uncle != null && uncle.color == RED) {
                    grandparent.color = RED;
                    parent.color = BLACK;
                    uncle.color = BLACK;
                    node = grandparent;
                } else {
                    // Case 2: Node is left child → right rotate
                    if (node == parent.left) {
                        node = parent;
                        rightRotate(node);
                    }
                    // Case 3: Node is right child → left rotate
                    parent.color = BLACK;
                    grandparent.color = RED;
                    leftRotate(grandparent);
                }
            }
        }

        root.color = BLACK; // Always keep root BLACK
    }

    // Left rotation helper
    private void leftRotate(Node node) {
        Node rightChild = node.right;
        node.right = rightChild.left;

        if (rightChild.left != null)
            rightChild.left.parent = node;

        rightChild.parent = node.parent;

        if (node.parent == null)
            root = rightChild;
        else if (node == node.parent.left)
            node.parent.left = rightChild;
        else
            node.parent.right = rightChild;

        rightChild.left = node;
        node.parent = rightChild;
    }

    // Right rotation helper
    private void rightRotate(Node node) {
        Node leftChild = node.left;
        node.left = leftChild.right;

        if (leftChild.right != null)
            leftChild.right.parent = node;

        leftChild.parent = node.parent;

        if (node.parent == null)
            root = leftChild;
        else if (node == node.parent.left)
            node.parent.left = leftChild;
        else
            node.parent.right = leftChild;

        leftChild.right = node;
        node.parent = leftChild;
    }

    // Public method for preorder traversal
    public void preOrder() {
        preOrderHelper(root);
        System.out.println(); // For spacing
    }

    // Recursive preorder: root → left → right
    private void preOrderHelper(Node node) {
        if (node != null) {
            System.out.print(node.key + " ");
            preOrderHelper(node.left);
            preOrderHelper(node.right);
        }
    }

    // Public method to start postorder traversal
    public void printPostOrder() {
        postOrderHelper(root);
        System.out.println(); // For spacing
    }

    // Recursive postorder: left → right → root
    private void postOrderHelper(Node node) {
        if (node != null) {
            postOrderHelper(node.left);
            postOrderHelper(node.right);
            System.out.print(node.key + " ");
        }
    }
}


